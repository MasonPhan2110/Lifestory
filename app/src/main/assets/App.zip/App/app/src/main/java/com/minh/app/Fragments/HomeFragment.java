package com.minh.app.Fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.provider.ContactsContract;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.minh.app.CommentActivity;
import com.minh.app.CreatePostActivity;
import com.minh.app.EditActivity;
import com.minh.app.MainActivity;
import com.minh.app.Model.Group;
import com.minh.app.Model.Home;
import com.minh.app.Model.User;
import com.minh.app.ProfileActivity;
import com.minh.app.R;
import com.minh.app.ViewPictureActivity;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

public class HomeFragment extends Fragment implements MainActivity.MainActivityListener {
    Button CreatePost;
    CircleImageView profile_img;
    FirebaseUser fuser;
    List<Home> mhome;
    ArrayList<String> MypostID;
    LinearLayout mylayout;
    PopupWindow popupWindow;
    static String user_img;
    static String user_name;
    Calendar cal;
    String currenttime;
    MaterialCardView cardView;
    SwipeRefreshLayout refresh;
    int view_index;
    ScrollView scrollView;
    Field mScroller;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        setRetainInstance(true);
        // Inflate the layout for this fragment.
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        profile_img = view.findViewById(R.id.profile_image);
        CreatePost = view.findViewById(R.id.createpost);
        fuser = FirebaseAuth.getInstance().getCurrentUser();
        mylayout = (LinearLayout) view.findViewById(R.id.mylayout);
        mhome = new ArrayList<>();
        MypostID = new ArrayList<>();
        refresh = view.findViewById(R.id.refresh);
        scrollView = view.findViewById(R.id.scrollview);
        cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+7:00"));
        Date currentLocaltime = cal.getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+7:00"));
        currenttime = dateFormat.format(currentLocaltime);
        profile_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(),ProfileActivity.class);
                startActivity(intent);
            }
        });
        refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mylayout.removeViews(1, mylayout.getChildCount()-1);
                readHome();
                refresh.setRefreshing(false);
            }
        });
        readHome();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(fuser.getUid());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user = snapshot.getValue(User.class);
                user_img = user.getImageURL();
                user_name = user.getUsername();
                if(user.getImageURL().equals("default")){
                    profile_img.setImageResource(R.mipmap.ic_launcher);
                }else{
                    Glide.with(getContext()).load(user.getImageURL()).into(profile_img);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        CreatePost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), CreatePostActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
        return view;
    }
    private void readHome() {
        DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Post");
        reference1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mhome.clear();
                for (DataSnapshot dataSnapshot: snapshot.getChildren()){
                    Home home = dataSnapshot.getValue(Home.class);
                    home.setId(dataSnapshot.getKey());
                    mhome.add(home);
                }
                view_index = mhome.size();
                Collections.reverse(mhome);
                LayoutInflater layoutInflater = LayoutInflater.from(getContext());
                for(final Home item : mhome ){
                    final View view = layoutInflater.inflate(R.layout.item_home,mylayout,false);
                    final String id = item.getId();
                    final TextView username1, content, like_count, comment_count,username_share, content_share, name_gr;;
                    final ImageView picture,picture_share;
                    final CircleImageView profile_image, profile_image_share;
                    final Button like, liked, comment, share;
                    final String Creater = item.getCreater();
                    ImageButton menu_home;
                    RelativeLayout view_like;
                    name_gr = view.findViewById(R.id.name_gr);
                    menu_home = view.findViewById(R.id.menu_home);
                    cardView = view.findViewById(R.id.card_view);
                    username_share= view.findViewById(R.id.username_share);
                    content_share = view.findViewById(R.id.content_share);
                    profile_image_share = view.findViewById(R.id.profile_image_share);
                    picture_share = view.findViewById(R.id.picture_share);
                    share = view.findViewById(R.id.share);
                    view_like = view.findViewById(R.id.view_like);
                    comment_count = view.findViewById(R.id.comment_count);
                    username1 = view.findViewById(R.id.username);
                    content = view.findViewById(R.id.content);
                    like_count = view.findViewById(R.id.like_count);
                    profile_image = view.findViewById(R.id.profile_image);
                    picture = view.findViewById(R.id.picture);
                    like= view.findViewById(R.id.like);
                    liked= view.findViewById(R.id.liked);
                    comment = view.findViewById(R.id.comment);
                    if(!item.getPostToGr().equals("default")){
                        name_gr.setVisibility(View.VISIBLE);
                        final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Group")
                                .child(item.getPostToGr());
                        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                Group grp = snapshot.getValue(Group.class);
                                name_gr.setText(grp.getNameGroup());
                                databaseReference.child("Member").addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        Map<String, Object> map = (Map<String, Object>) snapshot.getValue();
                                        if(map.containsKey(fuser.getUid())){
                                            view.setVisibility(View.VISIBLE);                                       }
                                        else{
                                            view.setVisibility(View.GONE);
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }
                    username1.setText(item.getUsername());
                    username1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getContext(), ProfileActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("userid", Creater);
                            startActivity(intent);
                        }
                    });
                    profile_image.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getContext(), ProfileActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("userid", Creater);
                            startActivity(intent);
                        }
                    });
                    picture.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getContext(), ViewPictureActivity.class);
                            intent.putExtra("imgurl", item.getImg());
                            startActivity(intent);
                        }
                    });
                    if(!item.getIsshare().equals("True")){
                        cardView.setVisibility(View.GONE);
                        picture.setVisibility(View.VISIBLE);
                    }else{
                        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Post")
                                .child(item.getPostShare());
                        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                final Home home_shared = snapshot.getValue(Home.class);
                                final String img_share = home_shared.getImg();
                                username_share.setText(home_shared.getUsername());
                                content_share.setText(home_shared.getContent());
                                if(home_shared.getImageURL().equals("default")){
                                    profile_image_share.setImageResource(R.mipmap.ic_launcher);
                                }else{
                                    Glide.with(getContext()).load(home_shared.getImageURL()).into(profile_image_share);
                                }
                                if(home_shared.getImg().equals("default")){
                                    picture_share.setVisibility(View.GONE);
                                }else{
                                    Glide.with(getContext()).load(home_shared.getImg()).into(picture_share);
                                    picture_share.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent intent = new Intent(getContext(), ViewPictureActivity.class);
                                            intent.putExtra("imgurl", img_share);
                                            startActivity(intent);
                                        }
                                    });
                                }
                                username_share.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent intent = new Intent(getContext(), ProfileActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        intent.putExtra("userid", home_shared.getCreater());
                                        startActivity(intent);
                                    }
                                });
                                profile_image_share.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent intent = new Intent(getContext(), ProfileActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        intent.putExtra("userid", home_shared.getCreater());
                                        startActivity(intent);
                                    }
                                });
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }
                    if(item.getContent().equals("default")){
                        content.setVisibility(View.VISIBLE);
                    }else {
                        content.setText(item.getContent());
                    }
                    if(item.getImageURL().equals("default")){
                        profile_image.setImageResource(R.mipmap.ic_launcher);
                    }else{
                        Glide.with(getContext()).load(item.getImageURL()).into(profile_image);
                    }
                    if(item.getImg().equals("default")){
                        picture.setVisibility(View.GONE);
                    }else{
                        Glide.with(getContext()).load(item.getImg()).into(picture);
                    }
                    view_like.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getContext(), CommentActivity.class);
                            intent.putExtra("homeid", id);
                            startActivity(intent);
                        }
                    });
                    menu_home.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            menu_home_popup(item.getCreater(), v, item.getId());
                        }
                    });
                    DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Like")
                            .child(item.getId());
                    reference1.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            Map<String, Object> liker = (HashMap<String, Object>) snapshot.getValue();
                            int likecount = (int) snapshot.getChildrenCount();
                            Log.e("AAA", String.valueOf(likecount));
                            if(liker!=null){
                                if(liker.containsKey(fuser.getUid())){
                                    liked.setVisibility(View.VISIBLE);
                                    like.setVisibility(View.GONE);
                                }
                            }else{
                                liked.setVisibility(View.GONE);
                                like.setVisibility(View.VISIBLE);
                                like_count.setText("");
                            }
                            if (likecount == 0){
                                like_count.setVisibility(View.VISIBLE);
                            }else if(likecount == 1){
                                like_count.setText(likecount +" like");
                            }
                            else{
                                like_count.setText(likecount +" likes");
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                    share.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
                            View menupopup = layoutInflater.inflate(R.layout.sharepost, null);
                            int width = RelativeLayout.LayoutParams.MATCH_PARENT;
                            int heigh = RelativeLayout.LayoutParams.WRAP_CONTENT;
                            //boolean focusable = true;
                            popupWindow = new PopupWindow(menupopup, width,heigh,true);
                            popupWindow.showAtLocation(v, Gravity.START,0,0);

                            View container = (View) popupWindow.getContentView().getParent();
                            WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
                            WindowManager.LayoutParams p = (WindowManager.LayoutParams) container.getLayoutParams();
                            p.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
                            p.dimAmount = 0.3f;
                            wm.updateViewLayout(container, p);
                            CircleImageView profile_img;
                            final EditText post;
                            Button sharenow;
                            TextView username;
                            profile_img = menupopup.findViewById(R.id.profile_img);
                            post = menupopup.findViewById(R.id.post);
                            username = menupopup.findViewById(R.id.username);
                            sharenow = menupopup.findViewById(R.id.share);
                            if (user_img.equals("default")){
                                profile_img.setImageResource(R.mipmap.ic_launcher);
                            }else{
                                Glide.with(getContext()).load(user_img).into(profile_img);
                            }
                            username.setText(user_name);
                            sharenow.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    sharepost(fuser.getUid(), id,user_name, post.getText().toString(), user_img, item.getPostShare());
                                    if(!fuser.getUid().equals(item.getCreater())) {
                                        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Noti")
                                                .child(item.getCreater());
                                        String key = databaseReference.push().getKey();
                                        HashMap<String, Object> map = new HashMap<>();
                                        map.put("ID",key);
                                        map.put("Sent", fuser.getUid());
                                        map.put("Post", item.getId());
                                        map.put("Type","Share");
                                        map.put("IsRead","False");
                                        databaseReference.child(key).updateChildren(map);
                                    }
                                    popupWindow.dismiss();
                                }
                            });
                        }
                    });
                    like.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            liked.setVisibility(View.VISIBLE);
                            like.setVisibility(View.GONE);
                            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Like")
                                    .child(id);
                            HashMap<String, Object> hashMap = new HashMap<>();
                            hashMap.put(fuser.getUid(), "Like");
                            reference.updateChildren(hashMap);
                            if(!fuser.getUid().equals(item.getCreater())) {
                                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Noti")
                                        .child(item.getCreater());
                                String key = databaseReference.push().getKey();
                                HashMap<String, Object> map = new HashMap<>();
                                map.put("ID",key);
                                map.put("Sent", fuser.getUid());
                                map.put("Post", item.getId());
                                map.put("Type","Like");
                                map.put("IsRead","False");
                                databaseReference.child(key).updateChildren(map);
                            }
                        }
                    });
                    liked.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Like")
                                    .child(id)
                                    .child(fuser.getUid());
                            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    snapshot.getRef().removeValue();
                                    like.setVisibility(View.VISIBLE);
                                    liked.setVisibility(View.GONE);
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                }
                            });
                        }
                    });
                    comment.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getContext(), CommentActivity.class);
                            intent.putExtra("homeid", id);
                            startActivity(intent);
                        }
                    });
                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Comment")
                            .child(id);
                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            int commentcount = (int) snapshot.getChildrenCount();
                            if(commentcount == 0) {
                                comment_count.setText("");
                            }else if(commentcount ==1){
                                comment_count.setText("1 comment");
                            }else{
                                comment_count.setText(commentcount + " comments");
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                    Log.e("BBB", item.getPostToGr());
                    if(item.getPostToGr().equals("default")){
                        mylayout.addView(view);
                    }
                    if(!item.getPostToGr().equals("default")) {
                        DatabaseReference databaseReference1 = FirebaseDatabase.getInstance().getReference("Group")
                                .child(item.getPostToGr())
                                .child("Member");
                        databaseReference1.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                HashMap<String, Object> hashMap = (HashMap<String, Object>) snapshot.getValue();
                                if (hashMap.containsKey(fuser.getUid())) {
                                    mylayout.addView(view);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }
//                    mylayout.addView(view);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    private void menu_home_popup(String creater, View v, final String id) {
        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
        final View menupopup = layoutInflater.inflate(R.layout.menu_home, null);
        int width = RelativeLayout.LayoutParams.MATCH_PARENT;
        int heigh = RelativeLayout.LayoutParams.WRAP_CONTENT;
        //boolean focusable = true;
        popupWindow = new PopupWindow(menupopup, width,heigh,true);
        popupWindow.showAtLocation(v, Gravity.BOTTOM,0,0);
        View container = (View) popupWindow.getContentView().getParent();
        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        WindowManager.LayoutParams p = (WindowManager.LayoutParams) container.getLayoutParams();
        p.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        p.dimAmount = 0.3f;
        wm.updateViewLayout(container, p);
        Button edit_post, delete_post, save_post, hide_post;
        hide_post = menupopup.findViewById(R.id.hide_post);
        edit_post = menupopup.findViewById(R.id.edit_post);
        delete_post = menupopup.findViewById(R.id.delete_post);
        save_post = menupopup.findViewById(R.id.save_post);
        if(!creater.equals(fuser.getUid())){
            hide_post.setVisibility(View.VISIBLE);
        }
        if(creater.equals(fuser.getUid())){
            edit_post.setVisibility(View.VISIBLE);
            delete_post.setVisibility(View.VISIBLE);
        }
        edit_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), EditActivity.class);
                startActivity(intent);
            }
        });
        delete_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Post").child(id);
                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        snapshot.getRef().removeValue();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Like").child(id);
                reference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        snapshot.getRef().removeValue();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Comment").child(id);
                reference1.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        snapshot.getRef().removeValue();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                popupWindow.dismiss();
            }
        });
    }
    private void sharepost(final String userid, final String id, final String user_name, final String content, final String img_url, final String postshare){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Post");
        HashMap<String, Object> hashMap= new HashMap<>();
        if (content.equals("")){
            hashMap.put("Content", "default");
        }else {
            hashMap.put("Content", content);
        }
        hashMap.put("Creater",userid);
        hashMap.put("username", user_name);
        hashMap.put("PostToGr","default");
        hashMap.put("PostToUser", "default");
        hashMap.put("imageURL", img_url);
        hashMap.put("TimePost", currenttime);
        hashMap.put("Img", "default");
        hashMap.put("Isshare", "True");
        if(postshare.equals("default")) {
            hashMap.put("PostShare", id);
        }else{
            hashMap.put("PostShare",postshare);
        }
        reference.push().setValue(hashMap);
    }
    @Override
    public void changeprofileimg() {
        fuser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Users")
                .child(fuser.getUid());
        reference1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                final User user = snapshot.getValue(User.class);
                final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Post");
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot: snapshot.getChildren()){
                            Home home = dataSnapshot.getValue(Home.class);
                            if(home.getCreater().equals(fuser.getUid())){
                                HashMap<String, Object> hashMap = new HashMap<>();
                                hashMap.put("imageURL", user.getImageURL());
                                databaseReference.child(dataSnapshot.getKey()).updateChildren(hashMap);
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    @Override
    public void backpress() {
        if(scrollView.getScrollY() != 0)
        {
            scrollView.fullScroll(View.FOCUS_UP);
        }else{
            getActivity().finishAffinity();
        }
    }

}