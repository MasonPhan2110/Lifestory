package com.minh.app.Adapter;

import android.content.Context;
import android.content.Intent;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.minh.app.CommentActivity;
import com.minh.app.Model.Home;
import com.minh.app.Model.User;
import com.minh.app.ProfileActivity;
import com.minh.app.R;
import com.minh.app.ViewPictureActivity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.ViewHolder> {
    private Context mcontext;
    private List<Home> mhome;
    private FirebaseUser fuser = FirebaseAuth.getInstance().getCurrentUser();
    private String username;
    private String profile_img;
    int likecount, commentcount;


    public HomeAdapter (Context mcontext, List<Home> mhome){
        this.mcontext = mcontext;
        this.mhome = mhome;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mcontext).inflate(R.layout.item_home, parent, false);
        return new HomeAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final Home home = mhome.get(position);
        final String homeid = home.getId();
        final String img = home.getImg();
        DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Like")
                .child(home.getId());
        reference1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map<String, Object> like = (HashMap<String, Object>) snapshot.getValue();
                likecount = (int) snapshot.getChildrenCount();

                if(like!=null){
                    if(like.containsKey(fuser.getUid())){
                        holder.liked.setVisibility(View.VISIBLE);
                        holder.like.setVisibility(View.GONE);
                    }
                }else{
                    holder.liked.setVisibility(View.GONE);
                    holder.like.setVisibility(View.VISIBLE);
                    holder.like_count.setText("");
                }
                if (likecount == 0){
                    holder.like_count.setVisibility(View.VISIBLE);
                }else if(likecount == 1){
                    holder.like_count.setText(likecount +" like");
                }
                else{
                    holder.like_count.setText(likecount +" likes");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Comment")
                .child(home.getId());
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map<String, Object> comment = (HashMap<String, Object>) snapshot.getValue();
                commentcount = (int) snapshot.getChildrenCount();
                if(commentcount == 0) {
                    holder.comment_count.setText("");
                }else if(commentcount ==1){
                    holder.comment_count.setText("1 comment");
                }else{
                    holder.comment_count.setText(commentcount + " comments");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        holder.username.setText(home.getUsername());
        if (home.getImageURL().equals("default")){
            holder.profile_image.setImageResource(R.mipmap.ic_launcher);
        }else {
            Glide.with(mcontext).load(home.getImageURL()).into(holder.profile_image);
        }
        holder.content.setText(home.getContent());
        if(home.getImg().equals("default")){
            holder.picture.setVisibility(View.GONE);
        }else{
            Glide.with(mcontext).load(home.getImg()).into(holder.picture);
            holder.picture.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent1 = new Intent(mcontext,ViewPictureActivity.class);
                    intent1.putExtra("imgurl", img);
                    mcontext.startActivity(intent1);
                }
            });
        }

        holder.like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                holder.like.setVisibility(View.GONE);
                holder.liked.setVisibility(View.VISIBLE);
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Like")
                        .child(homeid);
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put(fuser.getUid(), "Like");
                reference.updateChildren(hashMap);
            }
        });
        holder.liked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.like.setVisibility(View.VISIBLE);
//                holder.liked.setVisibility(View.GONE);
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Like")
                        .child(homeid)
                        .child(fuser.getUid());
                reference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        snapshot.getRef().removeValue();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
        holder.comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mcontext, CommentActivity.class);
                intent.putExtra("homeid", homeid);
                mcontext.startActivity(intent);
            }
        });
        holder.view_like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mcontext, CommentActivity.class);
                intent.putExtra("homeid", homeid);
                mcontext.startActivity(intent);
            }
        });
        holder.profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mcontext, ProfileActivity.class);
                if(!home.getCreater().equals(fuser.getUid())){
                    intent.putExtra("userid", home.getCreater());
                }
                mcontext.startActivity(intent);
            }
        });
        holder.username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mcontext, ProfileActivity.class);
                if(!home.getCreater().equals(fuser.getUid())){
                    intent.putExtra("userid", home.getCreater());
                }
                mcontext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mhome.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView username, content, like_count, comment_count;
        public ImageView picture;
        public CircleImageView profile_image;
        public Button like, liked, comment;
        public RelativeLayout view_like;
        //private ImageView img_on;
        //private ImageView img_off;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view_like = itemView.findViewById(R.id.view_like);
            comment_count = itemView.findViewById(R.id.comment_count);
            like_count= itemView.findViewById(R.id.like_count);
            comment = itemView.findViewById(R.id.comment);
            like = itemView.findViewById(R.id.like);
            liked = itemView.findViewById(R.id.liked);
            username = itemView.findViewById(R.id.username);
            profile_image = itemView.findViewById(R.id.profile_image);
            picture = itemView.findViewById(R.id.picture);
            content = itemView.findViewById(R.id.content);
        }
    }
}
