package com.minh.app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Group_for_NewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_for__new);
    }
}